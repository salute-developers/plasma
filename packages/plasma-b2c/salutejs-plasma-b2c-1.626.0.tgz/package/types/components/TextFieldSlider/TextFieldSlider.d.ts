export declare const TextFieldSliderDefault: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    sliderView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        gradient: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & (({
    value?: number | string;
    defaultValue?: number;
    decimalScale?: number;
    thousandsGroupStyle?: "thousand" | "lakh" | "wan" | "none";
    thousandSeparator?: boolean | string;
    decimalSeparator?: string;
    fixedDecimalScale?: boolean;
    appearance?: "default" | "clear";
    size?: string;
    view?: string;
    sliderView?: string;
    readOnly?: boolean;
    disabled?: boolean;
    onChange?: (event?: import("react").ChangeEvent<HTMLInputElement>, values?: {
        raw: string | number | undefined;
        formatted: string | number | undefined;
    }) => void;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: import("react").ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: import("@salutejs/plasma-new-hope/styled-components").PopoverPlacement | Array<import("@salutejs/plasma-new-hope/styled-components").PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: import("react").ReactNode;
    hintPortal?: string | import("react").RefObject<HTMLElement | null>;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hasScale?: boolean;
    titleCaption?: import("react").ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & {
    onChangeTextField?: (values?: {
        raw: string | number | undefined;
        formatted: string | number | undefined;
    }) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextFieldSlider/TextFieldSlider.types.js").SliderProps & Omit<import("react").InputHTMLAttributes<HTMLInputElement>, "onChange" | "required" | "size" | "value"> & import("react").RefAttributes<HTMLInputElement>) | ({
    value?: number | string;
    defaultValue?: number;
    decimalScale?: number;
    thousandsGroupStyle?: "thousand" | "lakh" | "wan" | "none";
    thousandSeparator?: boolean | string;
    decimalSeparator?: string;
    fixedDecimalScale?: boolean;
    appearance?: "default" | "clear";
    size?: string;
    view?: string;
    sliderView?: string;
    readOnly?: boolean;
    disabled?: boolean;
    onChange?: (event?: import("react").ChangeEvent<HTMLInputElement>, values?: {
        raw: string | number | undefined;
        formatted: string | number | undefined;
    }) => void;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hasScale?: boolean;
    titleCaption?: import("react").ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & {
    onChangeTextField?: (values?: {
        raw: string | number | undefined;
        formatted: string | number | undefined;
    }) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextFieldSlider/TextFieldSlider.types.js").SliderProps & Omit<import("react").InputHTMLAttributes<HTMLInputElement>, "onChange" | "required" | "size" | "value"> & import("react").RefAttributes<HTMLInputElement>))>;
export declare const TextFieldSliderClear: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    sliderView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        gradient: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & (({
    value?: number | string;
    defaultValue?: number;
    decimalScale?: number;
    thousandsGroupStyle?: "thousand" | "lakh" | "wan" | "none";
    thousandSeparator?: boolean | string;
    decimalSeparator?: string;
    fixedDecimalScale?: boolean;
    appearance?: "default" | "clear";
    size?: string;
    view?: string;
    sliderView?: string;
    readOnly?: boolean;
    disabled?: boolean;
    onChange?: (event?: import("react").ChangeEvent<HTMLInputElement>, values?: {
        raw: string | number | undefined;
        formatted: string | number | undefined;
    }) => void;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: import("react").ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: import("@salutejs/plasma-new-hope/styled-components").PopoverPlacement | Array<import("@salutejs/plasma-new-hope/styled-components").PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: import("react").ReactNode;
    hintPortal?: string | import("react").RefObject<HTMLElement | null>;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hasScale?: boolean;
    titleCaption?: import("react").ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & {
    onChangeTextField?: (values?: {
        raw: string | number | undefined;
        formatted: string | number | undefined;
    }) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextFieldSlider/TextFieldSlider.types.js").SliderProps & Omit<import("react").InputHTMLAttributes<HTMLInputElement>, "onChange" | "required" | "size" | "value"> & import("react").RefAttributes<HTMLInputElement>) | ({
    value?: number | string;
    defaultValue?: number;
    decimalScale?: number;
    thousandsGroupStyle?: "thousand" | "lakh" | "wan" | "none";
    thousandSeparator?: boolean | string;
    decimalSeparator?: string;
    fixedDecimalScale?: boolean;
    appearance?: "default" | "clear";
    size?: string;
    view?: string;
    sliderView?: string;
    readOnly?: boolean;
    disabled?: boolean;
    onChange?: (event?: import("react").ChangeEvent<HTMLInputElement>, values?: {
        raw: string | number | undefined;
        formatted: string | number | undefined;
    }) => void;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hasScale?: boolean;
    titleCaption?: import("react").ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & {
    onChangeTextField?: (values?: {
        raw: string | number | undefined;
        formatted: string | number | undefined;
    }) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextFieldSlider/TextFieldSlider.types.js").SliderProps & Omit<import("react").InputHTMLAttributes<HTMLInputElement>, "onChange" | "required" | "size" | "value"> & import("react").RefAttributes<HTMLInputElement>))>;
export declare const TextFieldSlider: import("react").ForwardRefExoticComponent<(((Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    sliderView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        gradient: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    value?: number | string;
    defaultValue?: number;
    decimalScale?: number;
    thousandsGroupStyle?: "thousand" | "lakh" | "wan" | "none";
    thousandSeparator?: boolean | string;
    decimalSeparator?: string;
    fixedDecimalScale?: boolean;
    appearance?: "default" | "clear";
    size?: string;
    view?: string;
    sliderView?: string;
    readOnly?: boolean;
    disabled?: boolean;
    onChange?: (event?: import("react").ChangeEvent<HTMLInputElement>, values?: {
        raw: string | number | undefined;
        formatted: string | number | undefined;
    }) => void;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: import("react").ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: import("@salutejs/plasma-new-hope/styled-components").PopoverPlacement | Array<import("@salutejs/plasma-new-hope/styled-components").PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: import("react").ReactNode;
    hintPortal?: string | import("react").RefObject<HTMLElement | null>;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hasScale?: boolean;
    titleCaption?: import("react").ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & {
    onChangeTextField?: (values?: {
        raw: string | number | undefined;
        formatted: string | number | undefined;
    }) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextFieldSlider/TextFieldSlider.types.js").SliderProps & Omit<import("react").InputHTMLAttributes<HTMLInputElement>, "onChange" | "required" | "size" | "value"> & import("react").RefAttributes<HTMLInputElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    sliderView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        gradient: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    value?: number | string;
    defaultValue?: number;
    decimalScale?: number;
    thousandsGroupStyle?: "thousand" | "lakh" | "wan" | "none";
    thousandSeparator?: boolean | string;
    decimalSeparator?: string;
    fixedDecimalScale?: boolean;
    appearance?: "default" | "clear";
    size?: string;
    view?: string;
    sliderView?: string;
    readOnly?: boolean;
    disabled?: boolean;
    onChange?: (event?: import("react").ChangeEvent<HTMLInputElement>, values?: {
        raw: string | number | undefined;
        formatted: string | number | undefined;
    }) => void;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hasScale?: boolean;
    titleCaption?: import("react").ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & {
    onChangeTextField?: (values?: {
        raw: string | number | undefined;
        formatted: string | number | undefined;
    }) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextFieldSlider/TextFieldSlider.types.js").SliderProps & Omit<import("react").InputHTMLAttributes<HTMLInputElement>, "onChange" | "required" | "size" | "value"> & import("react").RefAttributes<HTMLInputElement>, "ref">, "appearance">) & {
    appearance?: "default";
}) | ((Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    sliderView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        gradient: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    value?: number | string;
    defaultValue?: number;
    decimalScale?: number;
    thousandsGroupStyle?: "thousand" | "lakh" | "wan" | "none";
    thousandSeparator?: boolean | string;
    decimalSeparator?: string;
    fixedDecimalScale?: boolean;
    appearance?: "default" | "clear";
    size?: string;
    view?: string;
    sliderView?: string;
    readOnly?: boolean;
    disabled?: boolean;
    onChange?: (event?: import("react").ChangeEvent<HTMLInputElement>, values?: {
        raw: string | number | undefined;
        formatted: string | number | undefined;
    }) => void;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: import("react").ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: import("@salutejs/plasma-new-hope/styled-components").PopoverPlacement | Array<import("@salutejs/plasma-new-hope/styled-components").PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: import("react").ReactNode;
    hintPortal?: string | import("react").RefObject<HTMLElement | null>;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hasScale?: boolean;
    titleCaption?: import("react").ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & {
    onChangeTextField?: (values?: {
        raw: string | number | undefined;
        formatted: string | number | undefined;
    }) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextFieldSlider/TextFieldSlider.types.js").SliderProps & Omit<import("react").InputHTMLAttributes<HTMLInputElement>, "onChange" | "required" | "size" | "value"> & import("react").RefAttributes<HTMLInputElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    sliderView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        gradient: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    value?: number | string;
    defaultValue?: number;
    decimalScale?: number;
    thousandsGroupStyle?: "thousand" | "lakh" | "wan" | "none";
    thousandSeparator?: boolean | string;
    decimalSeparator?: string;
    fixedDecimalScale?: boolean;
    appearance?: "default" | "clear";
    size?: string;
    view?: string;
    sliderView?: string;
    readOnly?: boolean;
    disabled?: boolean;
    onChange?: (event?: import("react").ChangeEvent<HTMLInputElement>, values?: {
        raw: string | number | undefined;
        formatted: string | number | undefined;
    }) => void;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hasScale?: boolean;
    titleCaption?: import("react").ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & {
    onChangeTextField?: (values?: {
        raw: string | number | undefined;
        formatted: string | number | undefined;
    }) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextFieldSlider/TextFieldSlider.types.js").SliderProps & Omit<import("react").InputHTMLAttributes<HTMLInputElement>, "onChange" | "required" | "size" | "value"> & import("react").RefAttributes<HTMLInputElement>, "ref">, "appearance">) & {
    appearance: "clear";
})) & import("react").RefAttributes<HTMLInputElement>>;
