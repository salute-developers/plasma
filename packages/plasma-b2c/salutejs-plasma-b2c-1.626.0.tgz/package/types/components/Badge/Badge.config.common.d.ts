export declare const sizeL: string;
export declare const sizeM: string;
export declare const sizeS: string;
export declare const sizeXS: string;
export declare const pilled: string;
