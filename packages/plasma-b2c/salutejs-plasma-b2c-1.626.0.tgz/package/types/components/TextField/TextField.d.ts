import React, { ComponentProps, ReactNode } from 'react';
import type { TextFieldProps } from '@salutejs/plasma-hope';
import type { PopoverPlacement, PopoverPlacementBasic } from '@salutejs/plasma-new-hope/styled-components';
import type { DistributivePick, DistributiveOmit } from '@salutejs/plasma-new-hope';
export declare const TextFieldDefault: React.FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & (({
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: boolean;
    hasDivider?: boolean;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: PopoverPlacement | Array<PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & {
    chips?: never;
    onChangeChips?: never;
    enumerationType?: "plain";
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
    chipType?: never;
    chipView?: never;
    chipValidator?: never;
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>) | ({
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: boolean;
    hasDivider?: boolean;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: PopoverPlacement | Array<PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & {
    enumerationType: "chip";
    onSearch?: never;
    chips?: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>;
    onChangeChips?: (value: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>) => void;
    chipType?: "default" | "text";
    chipView?: string;
    chipValidator?: (value: string) => {
        view?: string;
    };
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>) | ({
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: boolean;
    hasDivider?: boolean;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & {
    chips?: never;
    onChangeChips?: never;
    enumerationType?: "plain";
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
    chipType?: never;
    chipView?: never;
    chipValidator?: never;
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>) | ({
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: boolean;
    hasDivider?: boolean;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & {
    enumerationType: "chip";
    onSearch?: never;
    chips?: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>;
    onChangeChips?: (value: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>) => void;
    chipType?: "default" | "text";
    chipView?: string;
    chipValidator?: (value: string) => {
        view?: string;
    };
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>) | ({
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: false;
    hasDivider?: never;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: PopoverPlacement | Array<PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & {
    chips?: never;
    onChangeChips?: never;
    enumerationType?: "plain";
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
    chipType?: never;
    chipView?: never;
    chipValidator?: never;
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>) | ({
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: false;
    hasDivider?: never;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: PopoverPlacement | Array<PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & {
    enumerationType: "chip";
    onSearch?: never;
    chips?: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>;
    onChangeChips?: (value: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>) => void;
    chipType?: "default" | "text";
    chipView?: string;
    chipValidator?: (value: string) => {
        view?: string;
    };
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>) | ({
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: false;
    hasDivider?: never;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & {
    chips?: never;
    onChangeChips?: never;
    enumerationType?: "plain";
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
    chipType?: never;
    chipView?: never;
    chipValidator?: never;
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>) | ({
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: false;
    hasDivider?: never;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & {
    enumerationType: "chip";
    onSearch?: never;
    chips?: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>;
    onChangeChips?: (value: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>) => void;
    chipType?: "default" | "text";
    chipView?: string;
    chipValidator?: (value: string) => {
        view?: string;
    };
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>))>;
export declare const TextFieldClear: React.FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & (({
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: boolean;
    hasDivider?: boolean;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: PopoverPlacement | Array<PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & {
    chips?: never;
    onChangeChips?: never;
    enumerationType?: "plain";
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
    chipType?: never;
    chipView?: never;
    chipValidator?: never;
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>) | ({
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: boolean;
    hasDivider?: boolean;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: PopoverPlacement | Array<PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & {
    enumerationType: "chip";
    onSearch?: never;
    chips?: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>;
    onChangeChips?: (value: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>) => void;
    chipType?: "default" | "text";
    chipView?: string;
    chipValidator?: (value: string) => {
        view?: string;
    };
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>) | ({
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: boolean;
    hasDivider?: boolean;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & {
    chips?: never;
    onChangeChips?: never;
    enumerationType?: "plain";
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
    chipType?: never;
    chipView?: never;
    chipValidator?: never;
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>) | ({
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: boolean;
    hasDivider?: boolean;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & {
    enumerationType: "chip";
    onSearch?: never;
    chips?: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>;
    onChangeChips?: (value: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>) => void;
    chipType?: "default" | "text";
    chipView?: string;
    chipValidator?: (value: string) => {
        view?: string;
    };
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>) | ({
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: false;
    hasDivider?: never;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: PopoverPlacement | Array<PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & {
    chips?: never;
    onChangeChips?: never;
    enumerationType?: "plain";
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
    chipType?: never;
    chipView?: never;
    chipValidator?: never;
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>) | ({
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: false;
    hasDivider?: never;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: PopoverPlacement | Array<PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & {
    enumerationType: "chip";
    onSearch?: never;
    chips?: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>;
    onChangeChips?: (value: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>) => void;
    chipType?: "default" | "text";
    chipView?: string;
    chipValidator?: (value: string) => {
        view?: string;
    };
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>) | ({
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: false;
    hasDivider?: never;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & {
    chips?: never;
    onChangeChips?: never;
    enumerationType?: "plain";
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
    chipType?: never;
    chipView?: never;
    chipValidator?: never;
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>) | ({
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: false;
    hasDivider?: never;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & {
    enumerationType: "chip";
    onSearch?: never;
    chips?: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>;
    onChangeChips?: (value: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>) => void;
    chipType?: "default" | "text";
    chipView?: string;
    chipValidator?: (value: string) => {
        view?: string;
    };
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>))>;
export declare const TextFieldComponent: React.ForwardRefExoticComponent<(((Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: boolean;
    hasDivider?: boolean;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: PopoverPlacement | Array<PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & {
    chips?: never;
    onChangeChips?: never;
    enumerationType?: "plain";
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
    chipType?: never;
    chipView?: never;
    chipValidator?: never;
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: boolean;
    hasDivider?: boolean;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: PopoverPlacement | Array<PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & {
    enumerationType: "chip";
    onSearch?: never;
    chips?: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>;
    onChangeChips?: (value: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>) => void;
    chipType?: "default" | "text";
    chipView?: string;
    chipValidator?: (value: string) => {
        view?: string;
    };
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: boolean;
    hasDivider?: boolean;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & {
    chips?: never;
    onChangeChips?: never;
    enumerationType?: "plain";
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
    chipType?: never;
    chipView?: never;
    chipValidator?: never;
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: boolean;
    hasDivider?: boolean;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & {
    enumerationType: "chip";
    onSearch?: never;
    chips?: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>;
    onChangeChips?: (value: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>) => void;
    chipType?: "default" | "text";
    chipView?: string;
    chipValidator?: (value: string) => {
        view?: string;
    };
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: false;
    hasDivider?: never;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: PopoverPlacement | Array<PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & {
    chips?: never;
    onChangeChips?: never;
    enumerationType?: "plain";
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
    chipType?: never;
    chipView?: never;
    chipValidator?: never;
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: false;
    hasDivider?: never;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: PopoverPlacement | Array<PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & {
    enumerationType: "chip";
    onSearch?: never;
    chips?: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>;
    onChangeChips?: (value: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>) => void;
    chipType?: "default" | "text";
    chipView?: string;
    chipValidator?: (value: string) => {
        view?: string;
    };
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: false;
    hasDivider?: never;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & {
    chips?: never;
    onChangeChips?: never;
    enumerationType?: "plain";
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
    chipType?: never;
    chipView?: never;
    chipValidator?: never;
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: false;
    hasDivider?: never;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & {
    enumerationType: "chip";
    onSearch?: never;
    chips?: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>;
    onChangeChips?: (value: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>) => void;
    chipType?: "default" | "text";
    chipView?: string;
    chipValidator?: (value: string) => {
        view?: string;
    };
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>, "ref">, "appearance">) & {
    appearance?: "default";
}) | ((Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: boolean;
    hasDivider?: boolean;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: PopoverPlacement | Array<PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & {
    chips?: never;
    onChangeChips?: never;
    enumerationType?: "plain";
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
    chipType?: never;
    chipView?: never;
    chipValidator?: never;
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: boolean;
    hasDivider?: boolean;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: PopoverPlacement | Array<PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & {
    enumerationType: "chip";
    onSearch?: never;
    chips?: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>;
    onChangeChips?: (value: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>) => void;
    chipType?: "default" | "text";
    chipView?: string;
    chipValidator?: (value: string) => {
        view?: string;
    };
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: boolean;
    hasDivider?: boolean;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & {
    chips?: never;
    onChangeChips?: never;
    enumerationType?: "plain";
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
    chipType?: never;
    chipView?: never;
    chipValidator?: never;
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: boolean;
    hasDivider?: boolean;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & {
    enumerationType: "chip";
    onSearch?: never;
    chips?: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>;
    onChangeChips?: (value: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>) => void;
    chipType?: "default" | "text";
    chipView?: string;
    chipValidator?: (value: string) => {
        view?: string;
    };
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: false;
    hasDivider?: never;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: PopoverPlacement | Array<PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & {
    chips?: never;
    onChangeChips?: never;
    enumerationType?: "plain";
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
    chipType?: never;
    chipView?: never;
    chipValidator?: never;
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: false;
    hasDivider?: never;
} & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: PopoverPlacement | Array<PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & {
    enumerationType: "chip";
    onSearch?: never;
    chips?: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>;
    onChangeChips?: (value: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>) => void;
    chipType?: "default" | "text";
    chipView?: string;
    chipValidator?: (value: string) => {
        view?: string;
    };
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: false;
    hasDivider?: never;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & {
    chips?: never;
    onChangeChips?: never;
    enumerationType?: "plain";
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
    chipType?: never;
    chipView?: never;
    chipValidator?: never;
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    appearance?: "default" | "clear" | "viewMode";
    size?: string;
    view?: string;
    readOnly?: boolean;
    disabled?: boolean;
} & {
    titleCaption?: ReactNode;
    leftHelper?: ReactNode;
    rightHelper?: ReactNode;
    contentLeft?: React.ReactElement;
    contentRight?: React.ReactElement;
    textBefore?: string;
    textAfter?: string;
    onSearch?: (value: string, event?: React.KeyboardEvent<HTMLInputElement>) => void;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    clear?: false;
    hasDivider?: never;
} & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & {
    enumerationType: "chip";
    onSearch?: never;
    chips?: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>;
    onChangeChips?: (value: Array<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").TextFieldPrimitiveValue>) => void;
    chipType?: "default" | "text";
    chipView?: string;
    chipValidator?: (value: string) => {
        view?: string;
    };
} & Omit<import("@salutejs/plasma-new-hope/styled-components").InputHTMLAttributes<HTMLInputElement>, "required" | "size"> & React.RefAttributes<HTMLInputElement>, "ref">, "appearance">) & {
    appearance: "clear";
})) & React.RefAttributes<HTMLInputElement>>;
type newHopeTextFieldProps = ComponentProps<typeof TextFieldComponent>;
type ClearProps = {
    /**
     * view применяется с clear-токенами
     */
    clear?: boolean;
    /**
     * отобразить ли divider
     */
    hasDivider?: boolean;
} | {
    /**
     * view применяется с clear-токенами
     */
    clear?: false;
    /**
     * отобразить ли divider
     */
    hasDivider?: never;
};
type HintProps = {
    /**
     * Текст тултипа
     */
    hintText: string;
    /**
     * Способ открытия тултипа - наведение или клик мышью
     */
    hintTrigger?: 'hover' | 'click';
    /**
     * Вид тултипа
     */
    hintView?: 'default';
    /**
     * Размер тултипа
     */
    hintSize?: 's' | 'm';
    /**
     * Элемент, рядом с которым произойдет вызов всплывающего окна.
     * Если свойство не задано, применится иконка по умолчанию.
     */
    hintTarget?: ReactNode;
    /**
     * Расположение иконки подсказки, когда отсутствует label
     * или же он имеет labelPlacement='inner'.
     * @default `outer`
     */
    hintTargetPlacement?: 'inner' | 'outer';
    /**
     * Направление раскрытия тултипа.
     */
    hintPlacement?: PopoverPlacement | Array<PopoverPlacementBasic>;
    /**
     * Видимость стрелки (хвоста).
     */
    hintHasArrow?: boolean;
    /**
     * Отступ окна относительно элемента, у которого оно вызвано.
     * @default
     * [0, 8]
     */
    hintOffset?: [number, number];
    /**
     * Ширина окна (в rem).
     */
    hintWidth?: string;
    /**
     * Слот для контента слева, например `Icon`.
     */
    hintContentLeft?: ReactNode;
} | {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTarget?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
};
export type CustomTextFieldProps = DistributiveOmit<TextFieldProps, 'helperText'> & {
    /**
     * Подсказка для поля ввода.
     */
    helperText?: ReactNode;
} & DistributivePick<newHopeTextFieldProps, 'appearance' | 'enumerationType' | 'chips' | 'chipType' | 'onChangeChips' | 'titleCaption' | 'labelPlacement' | 'keepPlaceholder' | 'required' | 'requiredPlacement' | 'optional' | 'chipView' | 'chipValidator' | 'textBefore' | 'textAfter'> & ClearProps & HintProps;
/**
 * Поле ввода текста.
 */
export declare const TextField: React.ForwardRefExoticComponent<CustomTextFieldProps & React.RefAttributes<HTMLInputElement>>;
export {};
