import { FunctionComponent } from 'react';
import type { SpinnerProps } from '.';
/**
 * Компонент для отображения индикатора загрузки.
 */
export declare const Spinner: import("styled-components").StyledComponent<FunctionComponent<SpinnerProps>, any, {}, never>;
