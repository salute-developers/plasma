/**
 * Копонент-составляющая Скелетона
 */
export declare const LineSkeleton: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        lighter: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        body1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        body2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        body3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        button1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        button2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        caption: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        display1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        display2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        display3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        footnote1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        footnote2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        headline1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        headline2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        headline3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        headline4: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        paragraph1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        paragraph2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        underline: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        bodyL: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        bodyM: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        bodyS: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        bodyXS: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        bodyXXS: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        dsplL: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        dsplM: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        dsplS: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h4: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h5: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h6: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        textL: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        textM: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        textS: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        textXS: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("react").HTMLAttributes<HTMLDivElement> & import("@salutejs/plasma-new-hope/types/components/Skeleton/Skeleton.types.js").SkeletonSizeProps & import("@salutejs/plasma-new-hope/types/components/Skeleton/Skeleton.types.js").SkeletonBaseProps & import("@salutejs/plasma-new-hope/styled-components").SkeletonGradientProps & import("react").RefAttributes<HTMLDivElement>>;
/**
 * Компонент плейсхолдера нескольких строк текста.
 * Размеры компонента задаются с помощью констант и соответствуют размерам [типографических элементов](/?path=/docs/).
 */
export declare const TextSkeleton: import("react").FC<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        lighter: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        body1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        body2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        body3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        button1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        button2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        caption: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        display1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        display2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        display3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        footnote1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        footnote2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        headline1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        headline2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        headline3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        headline4: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        paragraph1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        paragraph2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        underline: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        bodyL: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        bodyM: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        bodyS: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        bodyXS: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        bodyXXS: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        dsplL: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        dsplM: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        dsplS: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h4: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h5: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h6: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        textL: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        textM: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        textS: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        textXS: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("react").HTMLAttributes<HTMLDivElement> & import("@salutejs/plasma-new-hope/types/components/Skeleton/Skeleton.types.js").SkeletonSizeProps & import("@salutejs/plasma-new-hope/types/components/Skeleton/Skeleton.types.js").SkeletonBaseProps & import("@salutejs/plasma-new-hope/styled-components").SkeletonGradientProps & import("react").RefAttributes<HTMLDivElement> & {
    lines: number;
    width?: string | number;
}>;
/**
 * Компонент для создания прямоугольного плейсхолдера.
 */
export { RectSkeleton } from '@salutejs/plasma-new-hope/styled-components';
