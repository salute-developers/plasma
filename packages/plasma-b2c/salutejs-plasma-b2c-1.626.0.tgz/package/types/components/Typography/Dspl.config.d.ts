export declare const configL: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
export declare const configM: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
export declare const configS: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
