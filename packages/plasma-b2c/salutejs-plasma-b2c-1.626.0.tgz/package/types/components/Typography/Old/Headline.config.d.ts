export declare const configHeadline1: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            headline1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
export declare const configHeadline2: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            headline2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
export declare const configHeadline3: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            headline3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
export declare const configHeadline4: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            headline4: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
export declare const configHeadline5: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            headline5: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
