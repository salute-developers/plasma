export declare const Body1: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        body1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & (({
    noWrap?: boolean;
    breakWord?: boolean;
    color?: string;
    size?: string;
    isNumeric?: boolean;
    isItalic?: boolean;
} & import("@salutejs/plasma-new-hope/styled-components").SpacingProps & import("@salutejs/plasma-new-hope/types/components/Typography/Typography.types.js").MediumProps & import("@salutejs/plasma-new-hope/styled-components").AsProps & import("react").HTMLAttributes<HTMLDivElement> & {
    as?: keyof import("@salutejs/plasma-new-hope/styled-components").AllowedTextHTMLElements;
} & import("react").RefAttributes<HTMLDivElement>) | ({
    noWrap?: boolean;
    breakWord?: boolean;
    color?: string;
    size?: string;
    isNumeric?: boolean;
    isItalic?: boolean;
} & import("@salutejs/plasma-new-hope/styled-components").SpacingProps & import("@salutejs/plasma-new-hope/types/components/Typography/Typography.types.js").BoldProps & import("@salutejs/plasma-new-hope/styled-components").AsProps & import("react").HTMLAttributes<HTMLDivElement> & {
    as?: keyof import("@salutejs/plasma-new-hope/styled-components").AllowedTextHTMLElements;
} & import("react").RefAttributes<HTMLDivElement>) | ({
    noWrap?: boolean;
    breakWord?: boolean;
    color?: string;
    size?: string;
    isNumeric?: boolean;
    isItalic?: boolean;
} & import("@salutejs/plasma-new-hope/styled-components").SpacingProps & import("@salutejs/plasma-new-hope/types/components/Typography/Typography.types.js").ExtraBoldProps & import("@salutejs/plasma-new-hope/styled-components").AsProps & import("react").HTMLAttributes<HTMLDivElement> & {
    as?: keyof import("@salutejs/plasma-new-hope/styled-components").AllowedTextHTMLElements;
} & import("react").RefAttributes<HTMLDivElement>))>;
export declare const Body2: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        body2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & (({
    noWrap?: boolean;
    breakWord?: boolean;
    color?: string;
    size?: string;
    isNumeric?: boolean;
    isItalic?: boolean;
} & import("@salutejs/plasma-new-hope/styled-components").SpacingProps & import("@salutejs/plasma-new-hope/types/components/Typography/Typography.types.js").MediumProps & import("@salutejs/plasma-new-hope/styled-components").AsProps & import("react").HTMLAttributes<HTMLDivElement> & {
    as?: keyof import("@salutejs/plasma-new-hope/styled-components").AllowedTextHTMLElements;
} & import("react").RefAttributes<HTMLDivElement>) | ({
    noWrap?: boolean;
    breakWord?: boolean;
    color?: string;
    size?: string;
    isNumeric?: boolean;
    isItalic?: boolean;
} & import("@salutejs/plasma-new-hope/styled-components").SpacingProps & import("@salutejs/plasma-new-hope/types/components/Typography/Typography.types.js").BoldProps & import("@salutejs/plasma-new-hope/styled-components").AsProps & import("react").HTMLAttributes<HTMLDivElement> & {
    as?: keyof import("@salutejs/plasma-new-hope/styled-components").AllowedTextHTMLElements;
} & import("react").RefAttributes<HTMLDivElement>) | ({
    noWrap?: boolean;
    breakWord?: boolean;
    color?: string;
    size?: string;
    isNumeric?: boolean;
    isItalic?: boolean;
} & import("@salutejs/plasma-new-hope/styled-components").SpacingProps & import("@salutejs/plasma-new-hope/types/components/Typography/Typography.types.js").ExtraBoldProps & import("@salutejs/plasma-new-hope/styled-components").AsProps & import("react").HTMLAttributes<HTMLDivElement> & {
    as?: keyof import("@salutejs/plasma-new-hope/styled-components").AllowedTextHTMLElements;
} & import("react").RefAttributes<HTMLDivElement>))>;
export declare const Body3: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        body3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & (({
    noWrap?: boolean;
    breakWord?: boolean;
    color?: string;
    size?: string;
    isNumeric?: boolean;
    isItalic?: boolean;
} & import("@salutejs/plasma-new-hope/styled-components").SpacingProps & import("@salutejs/plasma-new-hope/types/components/Typography/Typography.types.js").MediumProps & import("@salutejs/plasma-new-hope/styled-components").AsProps & import("react").HTMLAttributes<HTMLDivElement> & {
    as?: keyof import("@salutejs/plasma-new-hope/styled-components").AllowedTextHTMLElements;
} & import("react").RefAttributes<HTMLDivElement>) | ({
    noWrap?: boolean;
    breakWord?: boolean;
    color?: string;
    size?: string;
    isNumeric?: boolean;
    isItalic?: boolean;
} & import("@salutejs/plasma-new-hope/styled-components").SpacingProps & import("@salutejs/plasma-new-hope/types/components/Typography/Typography.types.js").BoldProps & import("@salutejs/plasma-new-hope/styled-components").AsProps & import("react").HTMLAttributes<HTMLDivElement> & {
    as?: keyof import("@salutejs/plasma-new-hope/styled-components").AllowedTextHTMLElements;
} & import("react").RefAttributes<HTMLDivElement>) | ({
    noWrap?: boolean;
    breakWord?: boolean;
    color?: string;
    size?: string;
    isNumeric?: boolean;
    isItalic?: boolean;
} & import("@salutejs/plasma-new-hope/styled-components").SpacingProps & import("@salutejs/plasma-new-hope/types/components/Typography/Typography.types.js").ExtraBoldProps & import("@salutejs/plasma-new-hope/styled-components").AsProps & import("react").HTMLAttributes<HTMLDivElement> & {
    as?: keyof import("@salutejs/plasma-new-hope/styled-components").AllowedTextHTMLElements;
} & import("react").RefAttributes<HTMLDivElement>))>;
export declare const Button1: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        button1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const Button2: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        button2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const Caption: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const Display1: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        display1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const Display2: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        display2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const Display3: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        display3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const Footnote1: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        footnote1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const Footnote2: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        footnote2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const Headline1: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        headline1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const Headline2: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        headline2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const Headline3: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        headline3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const Headline4: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        headline4: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const Headline5: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        headline5: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const P1: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        paragraph1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const P2: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        paragraph2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const ParagraphText1: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        paragraphText1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const ParagraphText2: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        paragraphText2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const Underline: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Typography/Old/TypographyOld.js").TypographyOldProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const Subtitle: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/styled-components").SubtitleProps & import("react").RefAttributes<HTMLDivElement>>;
