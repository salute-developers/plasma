export declare const config: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
