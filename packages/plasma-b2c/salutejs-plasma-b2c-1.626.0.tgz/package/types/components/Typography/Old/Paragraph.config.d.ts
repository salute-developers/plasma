export declare const configParagraph1: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            paragraph1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
export declare const configParagraph2: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            paragraph2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
