export declare const configFootnote1: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            footnote1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
export declare const configFootnote2: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            footnote2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
