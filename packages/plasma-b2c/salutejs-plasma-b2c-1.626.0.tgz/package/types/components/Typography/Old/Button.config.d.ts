export declare const configButton1: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            button1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
export declare const configButton2: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            button2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
