export declare const configDisplay1: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            display1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
export declare const configDisplay2: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            display2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
export declare const configDisplay3: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            display3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
