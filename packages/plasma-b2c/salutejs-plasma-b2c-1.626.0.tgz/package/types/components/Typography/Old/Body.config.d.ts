export declare const configBody1: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            body1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
export declare const configBody2: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            body2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
export declare const configBody3: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            body3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
