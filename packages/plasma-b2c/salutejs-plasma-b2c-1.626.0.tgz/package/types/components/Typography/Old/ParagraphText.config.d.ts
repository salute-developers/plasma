export declare const configParagraphText1: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            paragraphText1: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
export declare const configParagraphText2: {
    defaults: {
        size: string;
    };
    variations: {
        size: {
            paragraphText2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
