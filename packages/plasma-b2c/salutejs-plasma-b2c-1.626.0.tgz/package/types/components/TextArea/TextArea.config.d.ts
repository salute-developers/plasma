export declare const config: {
    defaults: {
        view: string;
        focused: string;
    };
    variations: {
        view: {
            default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            /**
             * @deprecated
             * использовать `default`
             */
            primary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
        size: {
            xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
        hintView: {
            default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
        hintSize: {
            m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
        readOnly: {
            true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
        disabled: {
            true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
