import * as typographyComponents from '../Typography';
export declare const typographyVariants: typeof typographyComponents;
export declare const Editable: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/Editable/Editable.types.js").EditableProps<import("@salutejs/plasma-new-hope/types/components/Editable/Editable.types.js").TypographyVariants> & import("react").RefAttributes<HTMLInputElement>>;
