export declare const config: {
    view: {
        default: {
            trackColor: string;
            thumbColor: string;
            thumbHoverColor: string;
            thumbActiveColor: string;
        };
    };
    size: {
        s: {
            scrollWidth: string;
        };
        m: {
            scrollWidth: string;
        };
    };
};
