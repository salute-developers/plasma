export declare const config: {
    defaults: {
        view: string;
        size: string;
        progressSize: string;
    };
    variations: {
        view: {
            default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            primary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            accentGradient: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            info: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            success: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            error: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
        size: {
            l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
        progressSize: {
            2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            4: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            6: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            8: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
