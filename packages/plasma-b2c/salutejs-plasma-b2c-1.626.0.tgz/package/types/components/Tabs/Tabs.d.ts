import React, { ComponentProps } from 'react';
import { BaseTabsProps } from '@salutejs/plasma-new-hope/styled-components';
import { config as horizontalConfig } from './horizontal/HorizontalTabs.config';
declare const VerticalTabs: React.FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        divider: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    stretch: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & BaseTabsProps & import("@salutejs/plasma-new-hope/types/components/Tabs/Tabs.types.js").CustomVerticalTabsProps & React.RefAttributes<HTMLDivElement>>;
type Sizes = keyof typeof horizontalConfig['variations']['size'];
type Views = keyof typeof horizontalConfig['variations']['view'];
type CustomHorizontalTabsProps = {
    /**
     * Расположение табов
     */
    orientation?: 'horizontal';
    /**
     * Наличие divider
     * @default true
     */
    hasDivider?: boolean;
    /**
     * Табы растянуты на доступную область
     * @default false
     */
    stretch?: boolean;
    /**
     * Табы c округлым border-radius
     * @deprecated
     * @default false
     */
    pilled?: boolean;
    /**
     * Вид табов
     */
    view?: Views;
    /**
     * Размер табов
     */
    size?: Sizes;
    /**
     * Уберет скругление с выбранной стороны и подвинет контейнер
     * @deprecated
     */
    outsideScroll?: boolean | {
        left?: string;
        right?: string;
    };
};
type TabsProps = (BaseTabsProps & CustomHorizontalTabsProps) | ComponentProps<typeof VerticalTabs>;
/**
 * Контейнер вкладок, основной компонент для пользовательской сборки вкладок.
 */
export declare const Tabs: (props: TabsProps) => JSX.Element;
export {};
