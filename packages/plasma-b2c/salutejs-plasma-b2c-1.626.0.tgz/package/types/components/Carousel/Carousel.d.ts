import type { ComponentProps } from 'react';
import React from 'react';
import { CarouselOld } from './Legacy/Carousel';
declare const CarouselNew: React.FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/styled-components").CarouselNewProps & React.RefAttributes<HTMLDivElement>>;
type PropsOld = ComponentProps<typeof CarouselOld>;
type PropsNew = ComponentProps<typeof CarouselNew> & {
    index?: never;
};
type CarouselProps = PropsOld | PropsNew;
declare const Carousel: (props: CarouselProps & React.RefAttributes<HTMLInputElement>) => React.ReactElement | null;
export { Carousel };
export type { CarouselProps };
