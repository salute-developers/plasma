export declare const CarouselOld: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<import("@salutejs/plasma-new-hope/types/engines/types.js").Variants> & Omit<import("@salutejs/plasma-new-hope/types/components/Carousel/CarouselOld/Carousel.types.js").BasicProps & (import("@salutejs/plasma-new-hope/types/components/Carousel/CarouselOld/Carousel.types.js").DetectionProps | import("@salutejs/plasma-new-hope/types/components/Carousel/CarouselOld/Carousel.types.js").NoDetectionProps), "axis" | "animatedScrollByIndex" | "throttleMs" | "debounceMs"> & {
    ariaLive?: "off" | "polite";
    isDragScrollDisabled?: boolean;
} & import("react").RefAttributes<HTMLDivElement>>;
