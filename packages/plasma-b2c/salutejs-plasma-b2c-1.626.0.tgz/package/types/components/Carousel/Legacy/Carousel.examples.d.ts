import React, { FC } from 'react';
import { ImageProps } from '../../Image';
interface CarouselCardProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
    title: string;
    subtitle: string;
    imageSrc: string;
    imageAlt?: string;
    imageBase?: ImageProps['base'];
}
/**
 * Карточка под примеры с каруселью.
 * @private
 */
export declare const CarouselCard: FC<CarouselCardProps>;
export {};
