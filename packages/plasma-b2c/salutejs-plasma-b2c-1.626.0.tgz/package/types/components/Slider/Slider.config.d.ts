export declare const config: {
    defaults: {
        view: string;
        size: string;
        pointerSize: string;
        tickType: string;
    };
    variations: {
        view: {
            default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            gradient: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
        size: {
            l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
        pointerSize: {
            small: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            large: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            none: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
        disabled: {
            true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
