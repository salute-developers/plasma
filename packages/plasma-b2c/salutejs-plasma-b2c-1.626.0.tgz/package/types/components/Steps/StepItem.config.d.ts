export declare const config: {
    defaults: {
        view: string;
    };
    variations: {
        view: {
            default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
