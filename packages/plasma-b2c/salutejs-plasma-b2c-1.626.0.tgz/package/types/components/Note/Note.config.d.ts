export declare const config: {
    defaults: {
        view: string;
        size: string;
        orientation: string;
    };
    variations: {
        view: {
            default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            info: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
        size: {
            l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
        orientation: {
            vertical: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            horizontal: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
    intersections: {
        size: string;
        orientation: string;
        style: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    }[];
};
