import type { DropdownItemOption, DropdownProps } from '@salutejs/plasma-new-hope';
import React, { ComponentProps } from 'react';
declare const DropdownNewHope: React.FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    items: import("@salutejs/plasma-new-hope/types/components/Dropdown/Dropdown.types.js").ItemOption[];
    trigger?: import("@salutejs/plasma-new-hope/types/components/Dropdown/Dropdown.types.js").DropdownTrigger;
    placement?: import("@salutejs/plasma-new-hope/types/components/Dropdown/Dropdown.types.js").DropdownPlacement;
    children?: React.ReactNode;
    variant?: "normal" | "tight";
    zIndex?: React.CSSProperties["zIndex"];
    listMaxHeight?: React.CSSProperties["height"];
    listWidth?: React.CSSProperties["width"];
    portal?: string | React.RefObject<HTMLElement | null>;
    renderItem?: ((item: import("@salutejs/plasma-new-hope/types/components/Dropdown/Dropdown.types.js").ItemOption) => React.ReactNode) | undefined;
    beforeList?: React.ReactNode;
    afterList?: React.ReactNode;
    onToggle?: (isOpen: boolean, event?: React.SyntheticEvent | Event) => void;
    alwaysOpened?: boolean;
    onHover?: ((index: number, item: import("@salutejs/plasma-new-hope/types/components/Dropdown/Dropdown.types.js").ItemOption) => void) | undefined;
    onItemSelect?: ((item: import("@salutejs/plasma-new-hope/types/components/Dropdown/Dropdown.types.js").ItemOption, event: React.SyntheticEvent) => void) | undefined;
    openByRightClick?: boolean;
    offset?: [number, number];
    closeOnSelect?: boolean;
    closeOnOverlayClick?: boolean;
    itemRole?: string;
    disabled?: boolean;
    size?: string;
    view?: string;
} & React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
type Props<T extends DropdownItemOption> = Omit<DropdownProps<T>, 'size' | 'view'> & Pick<ComponentProps<typeof DropdownNewHope>, 'size' | 'view'>;
declare const Dropdown: <T extends DropdownItemOption>(props: Omit<DropdownProps<T>, "size" | "view"> & Pick<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & {
    items: import("@salutejs/plasma-new-hope/types/components/Dropdown/Dropdown.types.js").ItemOption[];
    trigger?: import("@salutejs/plasma-new-hope/types/components/Dropdown/Dropdown.types.js").DropdownTrigger;
    placement?: import("@salutejs/plasma-new-hope/types/components/Dropdown/Dropdown.types.js").DropdownPlacement;
    children?: React.ReactNode;
    variant?: "normal" | "tight";
    zIndex?: React.CSSProperties["zIndex"];
    listMaxHeight?: React.CSSProperties["height"];
    listWidth?: React.CSSProperties["width"];
    portal?: string | React.RefObject<HTMLElement | null>;
    renderItem?: ((item: import("@salutejs/plasma-new-hope/types/components/Dropdown/Dropdown.types.js").ItemOption) => React.ReactNode) | undefined;
    beforeList?: React.ReactNode;
    afterList?: React.ReactNode;
    onToggle?: (isOpen: boolean, event?: React.SyntheticEvent | Event) => void;
    alwaysOpened?: boolean;
    onHover?: ((index: number, item: import("@salutejs/plasma-new-hope/types/components/Dropdown/Dropdown.types.js").ItemOption) => void) | undefined;
    onItemSelect?: ((item: import("@salutejs/plasma-new-hope/types/components/Dropdown/Dropdown.types.js").ItemOption, event: React.SyntheticEvent) => void) | undefined;
    openByRightClick?: boolean;
    offset?: [number, number];
    closeOnSelect?: boolean;
    closeOnOverlayClick?: boolean;
    itemRole?: string;
    disabled?: boolean;
    size?: string;
    view?: string;
} & React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>, "size" | "view"> & React.RefAttributes<HTMLButtonElement>) => React.ReactElement | null;
export { Dropdown };
export type { Props as DropdownProps };
