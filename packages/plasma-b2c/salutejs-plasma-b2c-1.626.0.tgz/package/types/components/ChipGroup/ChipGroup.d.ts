export declare const ChipGroup: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    gap: {
        dense: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        wide: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    shape: {
        segmented: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/ChipGroup/ChipGroup.types.js").ChipGroupProps & import("react").RefAttributes<HTMLDivElement>>;
