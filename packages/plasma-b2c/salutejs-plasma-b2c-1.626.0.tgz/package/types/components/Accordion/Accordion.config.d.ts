export declare const config: {
    defaults: {
        view: string;
        size: string;
    };
    variations: {
        view: {
            default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            outlined: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            clear: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
        size: {
            l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            h2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            h3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            h4: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            h5: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            h6: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
        stretching: {
            filled: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            fixed: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
