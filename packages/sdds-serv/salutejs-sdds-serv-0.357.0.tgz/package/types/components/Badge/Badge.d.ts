export declare const BadgeDefault: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        dark: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        light: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    pilled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    transparent: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    clear: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & ((import("react").HTMLAttributes<HTMLDivElement> & {
    text?: string;
    customColor?: string;
    customBackgroundColor?: string;
    maxWidth?: import("react").CSSProperties["width"];
    pilled?: boolean;
    size?: string;
    view?: string;
    appearance?: "default" | "transparent" | "clear";
    clear?: boolean;
    transparent?: boolean;
} & {
    contentLeft?: import("react").ReactNode;
    contentRight?: never;
} & import("react").RefAttributes<HTMLDivElement>) | (import("react").HTMLAttributes<HTMLDivElement> & {
    text?: string;
    customColor?: string;
    customBackgroundColor?: string;
    maxWidth?: import("react").CSSProperties["width"];
    pilled?: boolean;
    size?: string;
    view?: string;
    appearance?: "default" | "transparent" | "clear";
    clear?: boolean;
    transparent?: boolean;
} & {
    contentLeft?: never;
    contentRight?: import("react").ReactNode;
} & import("react").RefAttributes<HTMLDivElement>))>;
export declare const BadgeClear: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        dark: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        light: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    pilled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    truncate: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & ((import("react").HTMLAttributes<HTMLDivElement> & {
    text?: string;
    customColor?: string;
    customBackgroundColor?: string;
    maxWidth?: import("react").CSSProperties["width"];
    pilled?: boolean;
    size?: string;
    view?: string;
    appearance?: "default" | "transparent" | "clear";
    clear?: boolean;
    transparent?: boolean;
} & {
    contentLeft?: import("react").ReactNode;
    contentRight?: never;
} & import("react").RefAttributes<HTMLDivElement>) | (import("react").HTMLAttributes<HTMLDivElement> & {
    text?: string;
    customColor?: string;
    customBackgroundColor?: string;
    maxWidth?: import("react").CSSProperties["width"];
    pilled?: boolean;
    size?: string;
    view?: string;
    appearance?: "default" | "transparent" | "clear";
    clear?: boolean;
    transparent?: boolean;
} & {
    contentLeft?: never;
    contentRight?: import("react").ReactNode;
} & import("react").RefAttributes<HTMLDivElement>))>;
export declare const BadgeTransparent: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        dark: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        light: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    pilled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    transparent: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    truncate: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & ((import("react").HTMLAttributes<HTMLDivElement> & {
    text?: string;
    customColor?: string;
    customBackgroundColor?: string;
    maxWidth?: import("react").CSSProperties["width"];
    pilled?: boolean;
    size?: string;
    view?: string;
    appearance?: "default" | "transparent" | "clear";
    clear?: boolean;
    transparent?: boolean;
} & {
    contentLeft?: import("react").ReactNode;
    contentRight?: never;
} & import("react").RefAttributes<HTMLDivElement>) | (import("react").HTMLAttributes<HTMLDivElement> & {
    text?: string;
    customColor?: string;
    customBackgroundColor?: string;
    maxWidth?: import("react").CSSProperties["width"];
    pilled?: boolean;
    size?: string;
    view?: string;
    appearance?: "default" | "transparent" | "clear";
    clear?: boolean;
    transparent?: boolean;
} & {
    contentLeft?: never;
    contentRight?: import("react").ReactNode;
} & import("react").RefAttributes<HTMLDivElement>))>;
/**
 * Компонент Badge.
 */
export declare const Badge: import("react").ForwardRefExoticComponent<(((Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        dark: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        light: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    pilled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    transparent: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    clear: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("react").HTMLAttributes<HTMLDivElement> & {
    text?: string;
    customColor?: string;
    customBackgroundColor?: string;
    maxWidth?: import("react").CSSProperties["width"];
    pilled?: boolean;
    size?: string;
    view?: string;
    appearance?: "default" | "transparent" | "clear";
    clear?: boolean;
    transparent?: boolean;
} & {
    contentLeft?: import("react").ReactNode;
    contentRight?: never;
} & import("react").RefAttributes<HTMLDivElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        dark: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        light: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    pilled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    transparent: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    clear: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("react").HTMLAttributes<HTMLDivElement> & {
    text?: string;
    customColor?: string;
    customBackgroundColor?: string;
    maxWidth?: import("react").CSSProperties["width"];
    pilled?: boolean;
    size?: string;
    view?: string;
    appearance?: "default" | "transparent" | "clear";
    clear?: boolean;
    transparent?: boolean;
} & {
    contentLeft?: never;
    contentRight?: import("react").ReactNode;
} & import("react").RefAttributes<HTMLDivElement>, "ref">, "appearance">) & {
    appearance?: "default";
}) | ((Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        dark: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        light: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    pilled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    truncate: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("react").HTMLAttributes<HTMLDivElement> & {
    text?: string;
    customColor?: string;
    customBackgroundColor?: string;
    maxWidth?: import("react").CSSProperties["width"];
    pilled?: boolean;
    size?: string;
    view?: string;
    appearance?: "default" | "transparent" | "clear";
    clear?: boolean;
    transparent?: boolean;
} & {
    contentLeft?: import("react").ReactNode;
    contentRight?: never;
} & import("react").RefAttributes<HTMLDivElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        dark: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        light: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    pilled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    truncate: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("react").HTMLAttributes<HTMLDivElement> & {
    text?: string;
    customColor?: string;
    customBackgroundColor?: string;
    maxWidth?: import("react").CSSProperties["width"];
    pilled?: boolean;
    size?: string;
    view?: string;
    appearance?: "default" | "transparent" | "clear";
    clear?: boolean;
    transparent?: boolean;
} & {
    contentLeft?: never;
    contentRight?: import("react").ReactNode;
} & import("react").RefAttributes<HTMLDivElement>, "ref">, "appearance">) & {
    appearance: "clear";
}) | ((Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        dark: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        light: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    pilled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    transparent: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    truncate: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("react").HTMLAttributes<HTMLDivElement> & {
    text?: string;
    customColor?: string;
    customBackgroundColor?: string;
    maxWidth?: import("react").CSSProperties["width"];
    pilled?: boolean;
    size?: string;
    view?: string;
    appearance?: "default" | "transparent" | "clear";
    clear?: boolean;
    transparent?: boolean;
} & {
    contentLeft?: import("react").ReactNode;
    contentRight?: never;
} & import("react").RefAttributes<HTMLDivElement>, "ref">, "appearance"> | Omit<Omit<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        dark: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        light: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    pilled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    transparent: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    truncate: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("react").HTMLAttributes<HTMLDivElement> & {
    text?: string;
    customColor?: string;
    customBackgroundColor?: string;
    maxWidth?: import("react").CSSProperties["width"];
    pilled?: boolean;
    size?: string;
    view?: string;
    appearance?: "default" | "transparent" | "clear";
    clear?: boolean;
    transparent?: boolean;
} & {
    contentLeft?: never;
    contentRight?: import("react").ReactNode;
} & import("react").RefAttributes<HTMLDivElement>, "ref">, "appearance">) & {
    appearance: "transparent";
})) & import("react").RefAttributes<HTMLDivElement>>;
