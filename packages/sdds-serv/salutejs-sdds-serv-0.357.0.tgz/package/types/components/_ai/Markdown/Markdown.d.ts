export declare const markdownMergedConfig: import("@salutejs/plasma-new-hope/styled-components").ComponentConfig<string, {
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}, import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}>, import("@salutejs/plasma-new-hope/types/components/_ai/Markdown/Markdown.types.js").MarkdownProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const Markdown: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/types/components/_ai/Markdown/Markdown.types.js").MarkdownProps & import("react").RefAttributes<HTMLDivElement>>;
