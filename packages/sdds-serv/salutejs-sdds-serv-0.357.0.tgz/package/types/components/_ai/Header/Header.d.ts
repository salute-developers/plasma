export declare const headerMergedConfig: import("@salutejs/plasma-new-hope/styled-components").ComponentConfig<string, {
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        clear: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h4: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h5: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}, import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        clear: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h4: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h5: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}>, import("@salutejs/plasma-new-hope/styled-components").HeaderProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const Header: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        clear: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h2: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h3: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h4: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        h5: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & import("@salutejs/plasma-new-hope/styled-components").HeaderProps & import("react").RefAttributes<HTMLDivElement>>;
