export declare const config: {
    defaults: {
        view: string;
        size: string;
    };
    variations: {
        view: {
            default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
        size: {
            xl: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
            xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        };
    };
};
