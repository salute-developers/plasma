import type { SelectProps as SelectPropsNewHope, SelectItemOption, DistributivePick, DistributiveOmit } from '@salutejs/plasma-new-hope';
import React, { ComponentProps } from 'react';
declare const SelectNewHope: React.FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        positive: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        warning: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        negative: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        clear: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        dark: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        black: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        white: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        xs: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    labelPlacement: {
        inner: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        outer: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    chipView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        secondary: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintView: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    hintSize: {
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    readOnly: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & ((import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").BasicProps<SelectItemOption> & {
    multiselect?: false;
    value?: string;
    defaultValue?: string;
    onChange?: ((value: string, item: SelectItemOption | null) => void) | undefined;
    isTargetAmount?: false;
    renderTarget?: ((value: SelectItemOption | null, opened?: boolean) => React.ReactNode) | undefined;
    selectAllOptions?: never;
} & {
    target?: "textfield-like";
    contentLeft?: React.ReactNode;
    contentRight?: React.ReactElement;
    placeholder?: string;
    helperText?: string;
    chipType?: "default" | "text";
    chipClickArea?: "full" | "close-icon";
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: React.ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: import("@salutejs/plasma-new-hope/styled-components").PopoverPlacement | Array<import("@salutejs/plasma-new-hope/styled-components").PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: React.ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & {
    _offset?: [number, number];
    _checkboxAppearance?: string;
} & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "defaultValue" | "placeholder" | "onChange" | "onScroll" | "value"> & React.RefAttributes<HTMLButtonElement>) | (import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").BasicProps<SelectItemOption> & {
    multiselect?: false;
    value?: string;
    defaultValue?: string;
    onChange?: ((value: string, item: SelectItemOption | null) => void) | undefined;
    isTargetAmount?: false;
    renderTarget?: ((value: SelectItemOption | null, opened?: boolean) => React.ReactNode) | undefined;
    selectAllOptions?: never;
} & {
    target?: "textfield-like";
    contentLeft?: React.ReactNode;
    contentRight?: React.ReactElement;
    placeholder?: string;
    helperText?: string;
    chipType?: "default" | "text";
    chipClickArea?: "full" | "close-icon";
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & {
    _offset?: [number, number];
    _checkboxAppearance?: string;
} & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "defaultValue" | "placeholder" | "onChange" | "onScroll" | "value"> & React.RefAttributes<HTMLButtonElement>) | (import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").BasicProps<SelectItemOption> & {
    multiselect: true;
    value?: string[];
    defaultValue?: string[];
    onChange?: ((value: string[], item: SelectItemOption | null) => void) | undefined;
    isTargetAmount?: true;
    renderTarget?: ((value: SelectItemOption[], opened?: boolean) => React.ReactNode) | undefined;
    selectAllOptions?: import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").SelectAllProps;
} & {
    target?: "textfield-like";
    contentLeft?: React.ReactNode;
    contentRight?: React.ReactElement;
    placeholder?: string;
    helperText?: string;
    chipType?: "default" | "text";
    chipClickArea?: "full" | "close-icon";
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: React.ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: import("@salutejs/plasma-new-hope/styled-components").PopoverPlacement | Array<import("@salutejs/plasma-new-hope/styled-components").PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: React.ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & {
    _offset?: [number, number];
    _checkboxAppearance?: string;
} & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "defaultValue" | "placeholder" | "onChange" | "onScroll" | "value"> & React.RefAttributes<HTMLButtonElement>) | (import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").BasicProps<SelectItemOption> & {
    multiselect: true;
    value?: string[];
    defaultValue?: string[];
    onChange?: ((value: string[], item: SelectItemOption | null) => void) | undefined;
    isTargetAmount?: true;
    renderTarget?: ((value: SelectItemOption[], opened?: boolean) => React.ReactNode) | undefined;
    selectAllOptions?: import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").SelectAllProps;
} & {
    target?: "textfield-like";
    contentLeft?: React.ReactNode;
    contentRight?: React.ReactElement;
    placeholder?: string;
    helperText?: string;
    chipType?: "default" | "text";
    chipClickArea?: "full" | "close-icon";
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & {
    _offset?: [number, number];
    _checkboxAppearance?: string;
} & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "defaultValue" | "placeholder" | "onChange" | "onScroll" | "value"> & React.RefAttributes<HTMLButtonElement>) | (import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").BasicProps<SelectItemOption> & Omit<{
    multiselect?: false;
    value?: string;
    defaultValue?: string;
    onChange?: ((value: string, item: SelectItemOption | null) => void) | undefined;
    isTargetAmount?: false;
    renderTarget?: ((value: SelectItemOption | null, opened?: boolean) => React.ReactNode) | undefined;
    selectAllOptions?: never;
}, "onChange" | "value"> & {
    name: string;
    value?: never;
    onChange?: React.ChangeEventHandler<HTMLSelectElement>;
} & {
    target?: "textfield-like";
    contentLeft?: React.ReactNode;
    contentRight?: React.ReactElement;
    placeholder?: string;
    helperText?: string;
    chipType?: "default" | "text";
    chipClickArea?: "full" | "close-icon";
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: React.ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: import("@salutejs/plasma-new-hope/styled-components").PopoverPlacement | Array<import("@salutejs/plasma-new-hope/styled-components").PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: React.ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & {
    _offset?: [number, number];
    _checkboxAppearance?: string;
} & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "defaultValue" | "placeholder" | "onChange" | "onScroll" | "value"> & React.RefAttributes<HTMLButtonElement>) | (import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").BasicProps<SelectItemOption> & Omit<{
    multiselect?: false;
    value?: string;
    defaultValue?: string;
    onChange?: ((value: string, item: SelectItemOption | null) => void) | undefined;
    isTargetAmount?: false;
    renderTarget?: ((value: SelectItemOption | null, opened?: boolean) => React.ReactNode) | undefined;
    selectAllOptions?: never;
}, "onChange" | "value"> & {
    name: string;
    value?: never;
    onChange?: React.ChangeEventHandler<HTMLSelectElement>;
} & {
    target?: "textfield-like";
    contentLeft?: React.ReactNode;
    contentRight?: React.ReactElement;
    placeholder?: string;
    helperText?: string;
    chipType?: "default" | "text";
    chipClickArea?: "full" | "close-icon";
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & {
    _offset?: [number, number];
    _checkboxAppearance?: string;
} & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "defaultValue" | "placeholder" | "onChange" | "onScroll" | "value"> & React.RefAttributes<HTMLButtonElement>) | (import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").BasicProps<SelectItemOption> & Omit<{
    multiselect: true;
    value?: string[];
    defaultValue?: string[];
    onChange?: ((value: string[], item: SelectItemOption | null) => void) | undefined;
    isTargetAmount?: true;
    renderTarget?: ((value: SelectItemOption[], opened?: boolean) => React.ReactNode) | undefined;
    selectAllOptions?: import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").SelectAllProps;
}, "onChange" | "value"> & {
    name: string;
    value?: never;
    onChange?: React.ChangeEventHandler<HTMLSelectElement>;
} & {
    target?: "textfield-like";
    contentLeft?: React.ReactNode;
    contentRight?: React.ReactElement;
    placeholder?: string;
    helperText?: string;
    chipType?: "default" | "text";
    chipClickArea?: "full" | "close-icon";
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: React.ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: import("@salutejs/plasma-new-hope/styled-components").PopoverPlacement | Array<import("@salutejs/plasma-new-hope/styled-components").PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: React.ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & {
    _offset?: [number, number];
    _checkboxAppearance?: string;
} & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "defaultValue" | "placeholder" | "onChange" | "onScroll" | "value"> & React.RefAttributes<HTMLButtonElement>) | (import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").BasicProps<SelectItemOption> & Omit<{
    multiselect: true;
    value?: string[];
    defaultValue?: string[];
    onChange?: ((value: string[], item: SelectItemOption | null) => void) | undefined;
    isTargetAmount?: true;
    renderTarget?: ((value: SelectItemOption[], opened?: boolean) => React.ReactNode) | undefined;
    selectAllOptions?: import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").SelectAllProps;
}, "onChange" | "value"> & {
    name: string;
    value?: never;
    onChange?: React.ChangeEventHandler<HTMLSelectElement>;
} & {
    target?: "textfield-like";
    contentLeft?: React.ReactNode;
    contentRight?: React.ReactElement;
    placeholder?: string;
    helperText?: string;
    chipType?: "default" | "text";
    chipClickArea?: "full" | "close-icon";
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps & {
    _offset?: [number, number];
    _checkboxAppearance?: string;
} & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "defaultValue" | "placeholder" | "onChange" | "onScroll" | "value"> & React.RefAttributes<HTMLButtonElement>) | (import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").BasicProps<SelectItemOption> & {
    multiselect?: false;
    value?: string;
    defaultValue?: string;
    onChange?: ((value: string, item: SelectItemOption | null) => void) | undefined;
    isTargetAmount?: false;
    renderTarget?: ((value: SelectItemOption | null, opened?: boolean) => React.ReactNode) | undefined;
    selectAllOptions?: never;
} & {
    target: "button-like";
    label?: string;
    contentLeft?: never;
    contentRight?: never;
    placeholder?: string;
    helperText?: never;
    keepPlaceholder?: never;
    chipType?: never;
    chipClickArea?: never;
} & import("@salutejs/plasma-new-hope/styled-components").NeverProps<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: React.ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: import("@salutejs/plasma-new-hope/styled-components").PopoverPlacement | Array<import("@salutejs/plasma-new-hope/styled-components").PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: React.ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & Omit<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps, "label">> & {
    _offset?: [number, number];
    _checkboxAppearance?: string;
} & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "defaultValue" | "placeholder" | "onChange" | "onScroll" | "value"> & React.RefAttributes<HTMLButtonElement>) | (import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").BasicProps<SelectItemOption> & {
    multiselect?: false;
    value?: string;
    defaultValue?: string;
    onChange?: ((value: string, item: SelectItemOption | null) => void) | undefined;
    isTargetAmount?: false;
    renderTarget?: ((value: SelectItemOption | null, opened?: boolean) => React.ReactNode) | undefined;
    selectAllOptions?: never;
} & {
    target: "button-like";
    label?: string;
    contentLeft?: never;
    contentRight?: never;
    placeholder?: string;
    helperText?: never;
    keepPlaceholder?: never;
    chipType?: never;
    chipClickArea?: never;
} & import("@salutejs/plasma-new-hope/styled-components").NeverProps<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & Omit<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps, "label">> & {
    _offset?: [number, number];
    _checkboxAppearance?: string;
} & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "defaultValue" | "placeholder" | "onChange" | "onScroll" | "value"> & React.RefAttributes<HTMLButtonElement>) | (import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").BasicProps<SelectItemOption> & {
    multiselect: true;
    value?: string[];
    defaultValue?: string[];
    onChange?: ((value: string[], item: SelectItemOption | null) => void) | undefined;
    isTargetAmount?: true;
    renderTarget?: ((value: SelectItemOption[], opened?: boolean) => React.ReactNode) | undefined;
    selectAllOptions?: import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").SelectAllProps;
} & {
    target: "button-like";
    label?: string;
    contentLeft?: never;
    contentRight?: never;
    placeholder?: string;
    helperText?: never;
    keepPlaceholder?: never;
    chipType?: never;
    chipClickArea?: never;
} & import("@salutejs/plasma-new-hope/styled-components").NeverProps<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: React.ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: import("@salutejs/plasma-new-hope/styled-components").PopoverPlacement | Array<import("@salutejs/plasma-new-hope/styled-components").PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: React.ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & Omit<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps, "label">> & {
    _offset?: [number, number];
    _checkboxAppearance?: string;
} & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "defaultValue" | "placeholder" | "onChange" | "onScroll" | "value"> & React.RefAttributes<HTMLButtonElement>) | (import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").BasicProps<SelectItemOption> & {
    multiselect: true;
    value?: string[];
    defaultValue?: string[];
    onChange?: ((value: string[], item: SelectItemOption | null) => void) | undefined;
    isTargetAmount?: true;
    renderTarget?: ((value: SelectItemOption[], opened?: boolean) => React.ReactNode) | undefined;
    selectAllOptions?: import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").SelectAllProps;
} & {
    target: "button-like";
    label?: string;
    contentLeft?: never;
    contentRight?: never;
    placeholder?: string;
    helperText?: never;
    keepPlaceholder?: never;
    chipType?: never;
    chipClickArea?: never;
} & import("@salutejs/plasma-new-hope/styled-components").NeverProps<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & Omit<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps, "label">> & {
    _offset?: [number, number];
    _checkboxAppearance?: string;
} & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "defaultValue" | "placeholder" | "onChange" | "onScroll" | "value"> & React.RefAttributes<HTMLButtonElement>) | (import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").BasicProps<SelectItemOption> & Omit<{
    multiselect?: false;
    value?: string;
    defaultValue?: string;
    onChange?: ((value: string, item: SelectItemOption | null) => void) | undefined;
    isTargetAmount?: false;
    renderTarget?: ((value: SelectItemOption | null, opened?: boolean) => React.ReactNode) | undefined;
    selectAllOptions?: never;
}, "onChange" | "value"> & {
    name: string;
    value?: never;
    onChange?: React.ChangeEventHandler<HTMLSelectElement>;
} & {
    target: "button-like";
    label?: string;
    contentLeft?: never;
    contentRight?: never;
    placeholder?: string;
    helperText?: never;
    keepPlaceholder?: never;
    chipType?: never;
    chipClickArea?: never;
} & import("@salutejs/plasma-new-hope/styled-components").NeverProps<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: React.ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: import("@salutejs/plasma-new-hope/styled-components").PopoverPlacement | Array<import("@salutejs/plasma-new-hope/styled-components").PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: React.ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & Omit<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps, "label">> & {
    _offset?: [number, number];
    _checkboxAppearance?: string;
} & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "defaultValue" | "placeholder" | "onChange" | "onScroll" | "value"> & React.RefAttributes<HTMLButtonElement>) | (import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").BasicProps<SelectItemOption> & Omit<{
    multiselect?: false;
    value?: string;
    defaultValue?: string;
    onChange?: ((value: string, item: SelectItemOption | null) => void) | undefined;
    isTargetAmount?: false;
    renderTarget?: ((value: SelectItemOption | null, opened?: boolean) => React.ReactNode) | undefined;
    selectAllOptions?: never;
}, "onChange" | "value"> & {
    name: string;
    value?: never;
    onChange?: React.ChangeEventHandler<HTMLSelectElement>;
} & {
    target: "button-like";
    label?: string;
    contentLeft?: never;
    contentRight?: never;
    placeholder?: string;
    helperText?: never;
    keepPlaceholder?: never;
    chipType?: never;
    chipClickArea?: never;
} & import("@salutejs/plasma-new-hope/styled-components").NeverProps<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & Omit<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps, "label">> & {
    _offset?: [number, number];
    _checkboxAppearance?: string;
} & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "defaultValue" | "placeholder" | "onChange" | "onScroll" | "value"> & React.RefAttributes<HTMLButtonElement>) | (import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").BasicProps<SelectItemOption> & Omit<{
    multiselect: true;
    value?: string[];
    defaultValue?: string[];
    onChange?: ((value: string[], item: SelectItemOption | null) => void) | undefined;
    isTargetAmount?: true;
    renderTarget?: ((value: SelectItemOption[], opened?: boolean) => React.ReactNode) | undefined;
    selectAllOptions?: import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").SelectAllProps;
}, "onChange" | "value"> & {
    name: string;
    value?: never;
    onChange?: React.ChangeEventHandler<HTMLSelectElement>;
} & {
    target: "button-like";
    label?: string;
    contentLeft?: never;
    contentRight?: never;
    placeholder?: string;
    helperText?: never;
    keepPlaceholder?: never;
    chipType?: never;
    chipClickArea?: never;
} & import("@salutejs/plasma-new-hope/styled-components").NeverProps<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hintText: string;
    hintTrigger?: "hover" | "click";
    hintView?: string;
    hintSize?: string;
    hintTargetIcon?: React.ReactNode;
    hintTargetPlacement?: "inner" | "outer";
    hintPlacement?: import("@salutejs/plasma-new-hope/styled-components").PopoverPlacement | Array<import("@salutejs/plasma-new-hope/styled-components").PopoverPlacementBasic>;
    hintHasArrow?: boolean;
    hintOffset?: [number, number];
    hintWidth?: string;
    hintContentLeft?: React.ReactNode;
    hintPortal?: string | React.RefObject<HTMLElement | null>;
} & Omit<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps, "label">> & {
    _offset?: [number, number];
    _checkboxAppearance?: string;
} & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "defaultValue" | "placeholder" | "onChange" | "onScroll" | "value"> & React.RefAttributes<HTMLButtonElement>) | (import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").BasicProps<SelectItemOption> & Omit<{
    multiselect: true;
    value?: string[];
    defaultValue?: string[];
    onChange?: ((value: string[], item: SelectItemOption | null) => void) | undefined;
    isTargetAmount?: true;
    renderTarget?: ((value: SelectItemOption[], opened?: boolean) => React.ReactNode) | undefined;
    selectAllOptions?: import("@salutejs/plasma-new-hope/types/components/Select/Select.types.js").SelectAllProps;
}, "onChange" | "value"> & {
    name: string;
    value?: never;
    onChange?: React.ChangeEventHandler<HTMLSelectElement>;
} & {
    target: "button-like";
    label?: string;
    contentLeft?: never;
    contentRight?: never;
    placeholder?: string;
    helperText?: never;
    keepPlaceholder?: never;
    chipType?: never;
    chipClickArea?: never;
} & import("@salutejs/plasma-new-hope/styled-components").NeverProps<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").RequiredProps & {
    hintTrigger?: never;
    hintText?: never;
    hintView?: never;
    hintSize?: never;
    hintTargetIcon?: never;
    hintTargetPlacement?: never;
    hintPlacement?: never;
    hintHasArrow?: never;
    hintOffset?: never;
    hintWidth?: never;
    hintContentLeft?: never;
    hintPortal?: never;
} & Omit<import("@salutejs/plasma-new-hope/types/components/TextField/TextField.types.js").LabelProps, "label">> & {
    _offset?: [number, number];
    _checkboxAppearance?: string;
} & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "defaultValue" | "placeholder" | "onChange" | "onScroll" | "value"> & React.RefAttributes<HTMLButtonElement>))>;
export type SelectProps<K extends SelectItemOption> = DistributiveOmit<SelectPropsNewHope<K>, 'size' | 'view' | 'chipView' | 'hintView' | 'hintSize' | 'labelPlacement'> & DistributivePick<ComponentProps<typeof SelectNewHope>, 'size' | 'view' | 'chipView' | 'hintView' | 'hintSize' | 'labelPlacement'>;
declare const Select: <K extends SelectItemOption>(props: SelectProps<K> & React.RefAttributes<HTMLButtonElement>) => React.ReactElement | null;
export { Select };
