/**
 * Слайдер позволяет определить числовое значение в пределах указанного промежутка.
 * Можно указать два значения.
 */
export declare const Slider: import("react").FunctionComponent<import("@salutejs/plasma-new-hope/types/engines/types.js").PropsType<{
    view: {
        default: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        accent: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        gradient: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    size: {
        l: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        m: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        s: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    pointerSize: {
        small: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        large: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
        none: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
    disabled: {
        true: import("@salutejs/plasma-new-hope/types/engines/types.js").PolymorphicClassName;
    };
}> & ((import("@salutejs/plasma-new-hope/types/components/Slider/components/SliderBase/SliderBase.types.js").SliderBaseProps & import("@salutejs/plasma-new-hope/types/components/Slider/components/index.js").SliderInternalProps & {
    onChange?: (event: import("@salutejs/plasma-new-hope/types/types/FormType.js").FormTypeNumber) => void;
    name: string;
    value?: never;
    defaultValue?: number;
} & {
    orientation?: "horizontal";
    labelPlacement?: "top" | "left" | "none";
    scaleAlign?: "top" | "side" | "bottom" | "none";
    sliderAlign?: never | "none";
    reversed?: never;
    labelReversed?: never;
    valuePlacement?: "top" | "bottom" | "none";
} & Omit<import("react").HTMLAttributes<HTMLDivElement>, "defaultValue" | "onChange"> & {
    onChangeCommitted?: (value: number) => void;
    ariaLabel?: string;
    showCurrentValue?: boolean;
    showRangeValues?: boolean;
    rangeValuesPlacement?: string;
    showScale?: boolean;
    hideMinValueDiff?: number;
    hideMaxValueDiff?: number;
    labelPlacement?: "inner" | "outer";
    labelContentLeft?: import("react").ReactNode;
    labelContent?: import("react").ReactNode;
    type?: "single";
    pointerSize?: "small" | "large" | "none";
    tickType?: "bullet" | "separator";
    pointerVisibility?: "always" | "hover";
    currentValueVisibility?: "always" | "hover";
    scaleTicks?: number[] | import("@salutejs/plasma-new-hope/types/components/Slider/components/Single/Single.types.js").ScaleTickItem[];
} & import("react").RefAttributes<HTMLDivElement>) | (import("@salutejs/plasma-new-hope/types/components/Slider/components/SliderBase/SliderBase.types.js").SliderBaseProps & import("@salutejs/plasma-new-hope/types/components/Slider/components/index.js").SliderInternalProps & {
    onChange?: (event: import("@salutejs/plasma-new-hope/types/types/FormType.js").FormTypeNumber) => void;
    name: string;
    value?: never;
    defaultValue?: number;
} & {
    orientation?: "vertical";
    sliderAlign?: "center" | "left" | "right" | "none";
    scaleAlign?: never;
    reversed?: boolean;
    labelReversed?: boolean;
    valuePlacement?: "left" | "right" | "none";
} & Omit<import("react").HTMLAttributes<HTMLDivElement>, "defaultValue" | "onChange"> & {
    onChangeCommitted?: (value: number) => void;
    ariaLabel?: string;
    showCurrentValue?: boolean;
    showRangeValues?: boolean;
    rangeValuesPlacement?: string;
    showScale?: boolean;
    hideMinValueDiff?: number;
    hideMaxValueDiff?: number;
    labelPlacement?: "inner" | "outer";
    labelContentLeft?: import("react").ReactNode;
    labelContent?: import("react").ReactNode;
    type?: "single";
    pointerSize?: "small" | "large" | "none";
    tickType?: "bullet" | "separator";
    pointerVisibility?: "always" | "hover";
    currentValueVisibility?: "always" | "hover";
    scaleTicks?: number[] | import("@salutejs/plasma-new-hope/types/components/Slider/components/Single/Single.types.js").ScaleTickItem[];
} & import("react").RefAttributes<HTMLDivElement>) | (import("@salutejs/plasma-new-hope/types/components/Slider/components/SliderBase/SliderBase.types.js").SliderBaseProps & import("@salutejs/plasma-new-hope/types/components/Slider/components/index.js").SliderInternalProps & {
    onChange?: (value: number) => void;
    value: number;
    name?: never;
    defaultValue?: never;
} & {
    orientation?: "horizontal";
    labelPlacement?: "top" | "left" | "none";
    scaleAlign?: "top" | "side" | "bottom" | "none";
    sliderAlign?: never | "none";
    reversed?: never;
    labelReversed?: never;
    valuePlacement?: "top" | "bottom" | "none";
} & Omit<import("react").HTMLAttributes<HTMLDivElement>, "defaultValue" | "onChange"> & {
    onChangeCommitted?: (value: number) => void;
    ariaLabel?: string;
    showCurrentValue?: boolean;
    showRangeValues?: boolean;
    rangeValuesPlacement?: string;
    showScale?: boolean;
    hideMinValueDiff?: number;
    hideMaxValueDiff?: number;
    labelPlacement?: "inner" | "outer";
    labelContentLeft?: import("react").ReactNode;
    labelContent?: import("react").ReactNode;
    type?: "single";
    pointerSize?: "small" | "large" | "none";
    tickType?: "bullet" | "separator";
    pointerVisibility?: "always" | "hover";
    currentValueVisibility?: "always" | "hover";
    scaleTicks?: number[] | import("@salutejs/plasma-new-hope/types/components/Slider/components/Single/Single.types.js").ScaleTickItem[];
} & import("react").RefAttributes<HTMLDivElement>) | (import("@salutejs/plasma-new-hope/types/components/Slider/components/SliderBase/SliderBase.types.js").SliderBaseProps & import("@salutejs/plasma-new-hope/types/components/Slider/components/index.js").SliderInternalProps & {
    onChange?: (value: number) => void;
    value: number;
    name?: never;
    defaultValue?: never;
} & {
    orientation?: "vertical";
    sliderAlign?: "center" | "left" | "right" | "none";
    scaleAlign?: never;
    reversed?: boolean;
    labelReversed?: boolean;
    valuePlacement?: "left" | "right" | "none";
} & Omit<import("react").HTMLAttributes<HTMLDivElement>, "defaultValue" | "onChange"> & {
    onChangeCommitted?: (value: number) => void;
    ariaLabel?: string;
    showCurrentValue?: boolean;
    showRangeValues?: boolean;
    rangeValuesPlacement?: string;
    showScale?: boolean;
    hideMinValueDiff?: number;
    hideMaxValueDiff?: number;
    labelPlacement?: "inner" | "outer";
    labelContentLeft?: import("react").ReactNode;
    labelContent?: import("react").ReactNode;
    type?: "single";
    pointerSize?: "small" | "large" | "none";
    tickType?: "bullet" | "separator";
    pointerVisibility?: "always" | "hover";
    currentValueVisibility?: "always" | "hover";
    scaleTicks?: number[] | import("@salutejs/plasma-new-hope/types/components/Slider/components/Single/Single.types.js").ScaleTickItem[];
} & import("react").RefAttributes<HTMLDivElement>) | (import("@salutejs/plasma-new-hope/types/components/Slider/components/SliderBase/SliderBase.types.js").SliderBaseProps & import("@salutejs/plasma-new-hope/types/components/Slider/components/index.js").SliderInternalProps & Omit<import("react").HTMLAttributes<HTMLDivElement>, "defaultValue" | "onChange"> & {
    onChange?: (event: import("@salutejs/plasma-new-hope/types/types/FormType.js").FormTypeString) => void;
    name?: string;
    value?: never;
    defaultValue?: number[];
} & {
    onChangeCommitted?: (value: number[]) => void;
    onChangeTextField?: (value: number[], event: import("react").ChangeEvent<HTMLInputElement>) => void;
    onBlurTextField?: (value: number[], event: import("react").FocusEvent<HTMLInputElement>) => void;
    onKeyDownTextField?: (value: number[], event: import("react").KeyboardEvent<HTMLInputElement>) => void;
    rangeValuesPlacement?: never;
    showCurrentValue?: never;
    showRangeValues?: never;
    labelPlacement?: never;
    ariaLabel?: string[];
    type?: "double";
} & import("react").RefAttributes<HTMLDivElement>) | (import("@salutejs/plasma-new-hope/types/components/Slider/components/SliderBase/SliderBase.types.js").SliderBaseProps & import("@salutejs/plasma-new-hope/types/components/Slider/components/index.js").SliderInternalProps & Omit<import("react").HTMLAttributes<HTMLDivElement>, "defaultValue" | "onChange"> & {
    onChange?: (value: number[]) => void;
    name?: never;
    value?: number[];
    defaultValue?: never;
} & {
    onChangeCommitted?: (value: number[]) => void;
    onChangeTextField?: (value: number[], event: import("react").ChangeEvent<HTMLInputElement>) => void;
    onBlurTextField?: (value: number[], event: import("react").FocusEvent<HTMLInputElement>) => void;
    onKeyDownTextField?: (value: number[], event: import("react").KeyboardEvent<HTMLInputElement>) => void;
    rangeValuesPlacement?: never;
    showCurrentValue?: never;
    showRangeValues?: never;
    labelPlacement?: never;
    ariaLabel?: string[];
    type?: "double";
} & import("react").RefAttributes<HTMLDivElement>))>;
