export { BodyL, BodyM, BodyS, BodyXS, BodyXXS, DsplL, DsplM, DsplS, H1, H2, H3, H4, H5, H6, TextL, TextM, TextS, TextXS, } from './Typography';
