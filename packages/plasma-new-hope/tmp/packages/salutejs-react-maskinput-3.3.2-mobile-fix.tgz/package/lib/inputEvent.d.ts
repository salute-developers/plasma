export declare type InputAction = {
    type: 'insert';
    value: string;
} | {
    type: 'backspace';
} | {
    type: 'delete';
};
export declare function getInputAction(inputType: string, data: string | null): InputAction | null;
