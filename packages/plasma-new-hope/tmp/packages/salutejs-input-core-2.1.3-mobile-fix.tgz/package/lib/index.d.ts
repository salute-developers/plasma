import { IInputParams, IInputState, IInputValue, IMaskedInput } from './interfaces/IInput';
import { IMaskItem, IMaskItemsMap } from './interfaces/IMaskItem';
import { ISelectRange } from './interfaces/ISelectRange';
export { IInputParams, IInputState, IInputValue, IMaskedInput, IMaskItem, IMaskItemsMap, ISelectRange };
export declare const defaults: {
    maskFormat: Array<IMaskItem>;
    maskChar: string;
    showMask: boolean;
    removeSelectedRange: Function;
    showStartChars: boolean;
};
export declare const createInput: (params: IInputParams) => IMaskedInput;
