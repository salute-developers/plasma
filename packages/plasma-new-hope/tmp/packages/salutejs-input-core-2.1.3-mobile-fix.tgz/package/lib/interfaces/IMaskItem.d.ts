export interface IMaskItem {
    str?: string;
    regexp?: RegExp;
    char?: string;
}
export interface IMaskItemsMap {
    [key: string]: IMaskItem;
}
