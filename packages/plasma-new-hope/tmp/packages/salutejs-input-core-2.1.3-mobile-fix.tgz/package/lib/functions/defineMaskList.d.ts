import { IMaskItemsMap, IMaskItem } from '../interfaces/IMaskItem';
/**
 *
 * @param {String} mask
 * @param format
 * @returns {Array}
 */
export default function defineMaskList(mask: String, format: IMaskItemsMap): Array<IMaskItem>;
