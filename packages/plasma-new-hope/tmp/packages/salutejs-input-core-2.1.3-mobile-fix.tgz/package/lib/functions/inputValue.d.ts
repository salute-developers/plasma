import { IInputValue, IInputState } from '../interfaces/IInput';
import { ISelectRange } from '../interfaces/ISelectRange';
import { IMaskItem } from '../interfaces/IMaskItem';
export default function inputValue(params: {
    data: Array<IInputValue>;
    input?: string;
    selection: ISelectRange;
    mask: Array<IMaskItem>;
    maskChar?: string;
    maskString?: string;
    showStartChars?: boolean;
}): IInputState;
