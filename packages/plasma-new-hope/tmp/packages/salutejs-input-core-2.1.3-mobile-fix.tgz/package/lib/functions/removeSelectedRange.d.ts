import { IInputValue } from '../interfaces/IInput';
import { ISelectRange } from '../interfaces/ISelectRange';
export default function removeSelectedRange(param: {
    value: Array<IInputValue>;
    selection: ISelectRange;
    maskChar: string;
    maskString: string;
}): Array<IInputValue>;
