import { ISelectRange } from '../interfaces/ISelectRange';
import { IMaskItem } from '../interfaces/IMaskItem';
import { IInputValue } from '../interfaces/IInput';
export declare function buildInputStrings(data: Array<IInputValue>, mask: Array<IMaskItem>, input: string, maskChar: string, maskString: string, selection: ISelectRange): {
    value: Array<IInputValue>;
    maskedValue: string;
    inputValuesApplied: number;
};
