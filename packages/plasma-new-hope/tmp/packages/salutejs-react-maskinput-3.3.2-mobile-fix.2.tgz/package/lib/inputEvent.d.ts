export declare type InputValueChange = {
    start: number;
    end: number;
    value: string;
};
/**
 * Converts a value already changed by the browser into an edit operation for input-core.
 * Mobile keyboards do not always provide cancellable beforeinput events, so onChange has
 * to recover the edit from the last rendered value and the new caret position.
 */
export declare function getInputValueChange(previousValue: string, nextValue: string, nextSelectionStart: number | null): InputValueChange | null;
